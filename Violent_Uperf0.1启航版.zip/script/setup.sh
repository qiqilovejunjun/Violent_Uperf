=#!/system/bin/sh
#
# Copyright (C) 2021-2022 Matt Yang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

sleep 0.7
echo 欢迎使用💝Violent_Uperf
sleep 0.7
echo 正在刷入中，请稍后......
sleep 1.2
echo Qi的大别墅 945414743
sleep 0.7
echo 刷入成功，祝您使用愉快❤️

BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libsysinfo.sh

# $1:error_message
abort() {
    echo "$1"
    echo "! Uperf下载失败"
    exit 1
}

# $1:file_node $2:owner $3:group $4:permission $5:secontext
set_perm() {
    chown $2:$3 $1
    chmod $4 $1
    chcon $5 $1
}

# $1:directory $2:owner $3:group $4:dir_permission $5:file_permission $6:secontext
set_perm_recursive() {
    find $1 -type d 2>/dev/null | while read dir; do
        set_perm $dir $2 $3 $4 $6
    done
    find $1 -type f -o -type l 2>/dev/null | while read file; do
        set_perm $file $2 $3 $5 $6
    done
}
install_wenk() {
    echo "👆🏻点按音量上键以选择你要安装的温控👆🏻"
    sleep 0.6
    echo "👇🏻点按音量下键取消安装👇🏻"
    userselect=""
    while [ "$userselect" = "" ]; do
        userselect="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
        sleep 0.3
    done
    case "$userselect" in
        "KEY_VOLUMEUP")
                userselect="你选择了安装温控"
                echo ⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻by Ralsei NEO⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻
                sleep 0.8
                echo "👆🏻点按音量上键下载极致温控(激进)👆🏻"
                sleep 0.6
                echo "👇🏻点按音量下键下载极致温控(保守)👇🏻"
                temp=""
                while [ "$temp" = "" ]; do
                     temp="$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')"
                sleep 0.3
                done
                    case "$temp" in
                        "KEY_VOLUMEUP")
                         sleep 0.8
                         echo "开始安装极致温控(激进)"
                         sleep 0.8
                         temp="你选择了安装极致温控(激进)"
                         magisk --install-module "$MODULE_PATH"/modules/temperaturef.zip
                        ;;
                        "KEY_VOLUMEDOWN")
                         sleep 0.8
                         echo "开始安装极致温控(保守)"
                         sleep 0.8
                         magisk --install-module "$MODULE_PATH"/modules/temperaturel.zip
                      temp="你选择了安装极致温控(保守)"
                        ;;
                        *)      
                    esac
        rm -rf "$MODULE_PATH"/modules/temperaturef.zip
        rm -rf "$MODULE_PATH"/modules/temperaturel.zip
        ;;
        "KEY_VOLUMEDOWN")
            sleep 0.6
            echo "取消安装"
            sleep 0.6
            userselect="你选择了不安装温控"
            temp="性能降低25%"
        ;;
        *)      
    esac
}

install_uperf() {
    echo "- 查找手机配置中"
    sleep 0.5
    echo "- CPU型号:$(getprop ro.board.platform)"
    sleep 0.5
    echo "- 手机代号:$(getprop ro.product.board)"

    local target
    local cfgname
    target="$(getprop ro.board.platform)"
    cfgname="$(get_config_name $target)"
    if [ "$cfgname" == "unsupported" ]; then
        target="$(getprop ro.product.board)"
        cfgname="$(get_config_name $target)"
    fi

    if [ "$cfgname" == "unsupported" ] || [ ! -f $MODULE_PATH/config/$cfgname.json ]; then
        abort "! 设备 [$target] 不被支持"
    fi
    sleep 0.7

    echo "- 配置文件在 $USER_PATH"
    mkdir -p $USER_PATH
    mv -f $USER_PATH/uperf.json $USER_PATH/uperf.json.bak
    cp -f $MODULE_PATH/config/$cfgname.json /data/adb/"$cfgname".json
    cp -f $MODULE_PATH/config/"$cfgname"e.json /data/adb/"$cfgname"e.json
    cp -f $SCRIPT_PATH/start.sh /data/adb/start.sh
    echo "- 配置文件转移成功"
    cp -f $MODULE_PATH/config/$cfgname.json $USER_PATH/uperf.json
    [ ! -e "$USER_PATH/perapp_powermode.txt" ] && cp $MODULE_PATH/config/perapp_powermode.txt $USER_PATH/perapp_powermode.txt
    rm -rf $MODULE_PATH/config
    cp -f $SCRIPT_PATH/ralseineo.sh /data/adb/modules/uperf/ralseineo.sh
    set_perm_recursive $BIN_PATH 0 0 0755 0755 u:object_r:system_file:s0
    sleep 0.7
}

install_wenkh() {
    echo "⭐你可以通过点按上/下音量键以选择是否安装极致温控⭐"
    sleep 0.6
    echo "⭐极致温控仅支持搭载骁龙芯片或联发科芯片的设备⭐"
    sleep 0.6
    echo "⭐极致温控模块(激进)功能如下⭐"
    sleep 0.6
    echo ⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻by Ralsei NEO⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻
    sleep 0.45
    echo "⭐1.将充电电流上限上调至22A⭐"
    sleep 0.45
    echo "⭐2.移除了大部分的温控⭐"
    sleep 0.45
    echo "⭐3.将电池温度锁定为25ºC,充电不再限制功率⭐"
    sleep 0.45
    echo "⭐4.将GPU温度墙上调至115ºC(仅联发科机型支持)⭐"
    sleep 0.45
    echo "⭐5.将充电时电池温度墙上调至70ºC(仅联发科机型支持)⭐"
    sleep 0.45
    echo "⭐6.将充电循环次数伪装至1次,以保证满速充电⭐"
    echo ⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻by Ralsei NEO⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻
    sleep 0.45
    echo "极致温控(保守)相对于激进版增加了一些功能"
    sleep 0.45
    echo "⭐1.充电时伪装温度，不充电时恢复原始电池温度⭐"
    sleep 0.45
    echo "⭐2.可以根据电池原始温度动态调节充电功率⭐"
    sleep 0.45
    echo ⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻by Ralsei NEO⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻
    sleep 0.45
}

install_uperf
install_wenkh
install_wenk
sleep 0.5
echo ⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻by Ralsei NEO⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻⁻
sleep 0.45
echo "* 你选择了$userselect"
sleep 0.45
echo "* $temp"
sleep 0.45
echo "* Uperf原项目地址:https://github.com/yc9559/uperf/"
sleep 0.5
echo "*修改版作者: 酷安@我还是睡觉edjns"
sleep 0.45
echo "* 版本: V0.1启航版"
sleep 0.45
echo "- 下载成功"
sleep 0.45
echo "成功安装Violent_Uperf"