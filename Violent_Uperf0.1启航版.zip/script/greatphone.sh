fpsgo_ged () {
    chmod 777 $2
    echo $1 > $2
    chmod 444 $2
}
soc=`cat /sys/devices/soc0/soc_id`
soc0=${soc:0:6}
echo $soc0
if [ "$soc0" = "MT6895" ]||[ "$soc0" = "MT6893" ]; then
    fpsgo_ged "0" /sys/kernel/fpsgo/common/fpsgo_enable
    fpsgo_ged "0" /sys/module/sspm_v3/holders/ged/parameters/is_GED_KPI_enabled
    fpsgo_ged "0" /sys/kernel/ged/hal/dcs_mode
fi
if [ "$soc0" = "MT6985" ]||[ "$soc0" = "MT6983" ]; then
    fpsgo_ged "0" /sys/kernel/fpsgo/common/fpsgo_enable
    fpsgo_ged "0" /sys/module/sspm_v3/holders/ged/parameters/is_GED_KPI_enabled
    fpsgo_ged "0" /sys/kernel/ged/hal/dcs_mode
fi