gpu_hz () {
    chmod 777 $2
    echo $1 > $2
}
    echo "1" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    gpu_hz "1" "/sys/class/kgsl/kgsl-3d0/max_pwrlevel"