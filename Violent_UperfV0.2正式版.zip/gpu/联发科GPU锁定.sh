echo 0 > /proc/gpufreqv2/fix_target_opp_index
echo 0 > /proc/gpufreq/gpufreq_opp_freq